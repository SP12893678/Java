package onlyfun.caterpillar.chat;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class SimpleChatClientUI extends JFrame {
    private Container container;
    private JTextField nickNameTextField, serverAddrTextField, serverPortTextField;
    private JButton connectToServerBtn;
    private JTextArea messageTextArea, typeInTextArea;
    
    private SimpleChatClient chatClient;
    
	public SimpleChatClientUI() {
	    super("Chat You And Me");
	    setUpUIComponent();
	    setUpEventListener();
	    setVisible(true);
	}
	
	private void setUpUIComponent() {
		setSize(600, 400);
		this.setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		container = getContentPane();
		JPanel panel = new JPanel();
		
		panel.setBorder(BorderFactory.createTitledBorder("Chat You And Me"));
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panel.add(new JLabel("Nickname"));
        panel.add(nickNameTextField = new JTextField(5));
        panel.add(new JLabel("Your Address"));
        panel.add(serverAddrTextField = new JTextField(10));
        panel.add(new JLabel("Lucky Number"));
        panel.add(serverPortTextField = new JTextField(5));
        panel.add(connectToServerBtn = new JButton("call you"));
        
        messageTextArea = new JTextArea(13, 50);
        messageTextArea.setLineWrap(true);
        messageTextArea.setWrapStyleWord(true);
        messageTextArea.setEditable(false);
        panel.add(new JScrollPane(messageTextArea)); 
        
        typeInTextArea = new JTextArea(2, 50);
        typeInTextArea.setLineWrap(true);
        typeInTextArea.setEditable(false);
        panel.add(new JScrollPane(typeInTextArea));
        
        container.add(panel);
    }
	
	private void setUpEventListener() {
		connectToServerBtn.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	connectToServerBtn.setEnabled(false);
                    	chatClient = new SimpleChatClient();
               
                		messageTextArea.append("call you...\n");
                		
                        new Thread(new Runnable(){
                            public void run() {
                            	try {
                          	        chatClient.connectToServer(serverAddrTextField.getText(), Integer.parseInt(serverPortTextField.getText()));
                          	        messageTextArea.append("hello! you are here....\n");
                          	        typeInTextArea.setEditable(true);
                          	      
                          	        String serverMessage;
                          	        while((serverMessage = chatClient.getServerMessage()) != null) {                          	        	
                          	        	messageTextArea.append(serverMessage + "\n");
                          	        	messageTextArea.setCaretPosition(messageTextArea.getText().length());
                          	        }
                            	}
                            	catch(IOException ex) {
                            		chatClient.closeConnection();
                            		JOptionPane.showMessageDialog(null, "see you..",
                                            "info", JOptionPane.INFORMATION_MESSAGE);
                            		connectToServerBtn.setEnabled(true);
                            		typeInTextArea.setEditable(false);
                            	}
                            }
                        }).start();
                    }
                }
            );
		
		typeInTextArea.addKeyListener(
				new KeyListener() {
					public void keyPressed(KeyEvent e) {}
			        public void keyTyped(KeyEvent e) {}
			        public void keyReleased(KeyEvent e) {
			        	if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			        		String message = nickNameTextField.getText() + " > " + typeInTextArea.getText();
			        		typeInTextArea.setText("");
			        		messageTextArea.append(message);
			        		messageTextArea.setCaretPosition(messageTextArea.getText().length());
			        		chatClient.sendMessageToServer(message.replace('\n', ' '));
			        	}
			        }
				}
			);
	}
	
	public static void main(String[] args) {
		new SimpleChatClientUI();
	}
}
