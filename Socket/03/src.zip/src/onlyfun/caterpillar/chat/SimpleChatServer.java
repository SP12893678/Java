package onlyfun.caterpillar.chat;

import java.net.*;
import java.io.*;

public class SimpleChatServer {
    private int serverPort;
    private ServerSocket serverSocket;
    private BufferedReader clientReader;
    private PrintStream clientWriter;
    
    public SimpleChatServer(int serverPort) {
        this.serverPort = serverPort;
    }
    
    public String waitForClient() throws IOException {
    	serverSocket = new ServerSocket(serverPort);
    	Socket clientSocket = serverSocket.accept();
    	
    	clientReader = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream()));
    	clientWriter = new PrintStream(clientSocket.getOutputStream());
    	
    	return clientSocket.getInetAddress().getHostName();
    }
    
    public String getClientMessage() throws IOException {
    	return clientReader.readLine();
    }
    
    public void sendMessageToClient(String message) {
    	clientWriter.println(message);
    }
    
    public void closeConnection() {
    	try {
            serverSocket.close();
    	}
    	catch(IOException e) {
    		
    	}
    }
}
