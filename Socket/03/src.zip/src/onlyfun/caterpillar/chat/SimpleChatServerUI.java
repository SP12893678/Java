package onlyfun.caterpillar.chat;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class SimpleChatServerUI extends JFrame {
    private Container container;
    private JTextField nickNameTextField, serverPortTextField;
    private JButton waitForClientBtn;
    private JTextArea messageTextArea, typeInTextArea;
    
    private SimpleChatServer chatServer;
    
	public SimpleChatServerUI() {
	    super("Chat You And Me");
	    setUpUIComponent();
	    setUpEventListener();
	    setVisible(true);
	}
	
	private void setUpUIComponent() {
		setSize(600, 400);
		this.setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		container = getContentPane();
		JPanel panel = new JPanel();
		
		panel.setBorder(BorderFactory.createTitledBorder("Chat You And Me"));
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panel.add(new JLabel("Nickname"));
        panel.add(nickNameTextField = new JTextField(5));
        panel.add(new JLabel("My Lucky Number"));
        panel.add(serverPortTextField = new JTextField(5));
        panel.add(waitForClientBtn = new JButton("wait for you"));
        
        messageTextArea = new JTextArea(13, 50);
        messageTextArea.setLineWrap(true);
        messageTextArea.setWrapStyleWord(true);
        messageTextArea.setEditable(false);
        panel.add(new JScrollPane(messageTextArea)); 
        
        typeInTextArea = new JTextArea(2, 50);
        typeInTextArea.setLineWrap(true);
        typeInTextArea.setEditable(false);
        panel.add(new JScrollPane(typeInTextArea));
        
        container.add(panel);
    }
	
	private void setUpEventListener() {
		waitForClientBtn.addActionListener(
                new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                    	waitForClientBtn.setEnabled(false);
                    	chatServer = new SimpleChatServer(
                    			Integer.parseInt(serverPortTextField.getText()));
               
                		messageTextArea.append("start to wait for you...\n");
                		
                        new Thread(new Runnable(){
                            public void run() {
                            	try {
                          	        chatServer.waitForClient();
                          	        messageTextArea.append("hello! you are here...\n");
                          	        typeInTextArea.setEditable(true);
                          	        
                          	        String clientMessage;
                          	        while((clientMessage = chatServer.getClientMessage()) != null) {                          	        	
                          	        	messageTextArea.append(clientMessage + "\n");
                          	        	messageTextArea.setCaretPosition(messageTextArea.getText().length());
                          	        }
                            	}
                            	catch(IOException ex) {
                            		chatServer.closeConnection();
                            		JOptionPane.showMessageDialog(null, "see you..",
                                            "info", JOptionPane.INFORMATION_MESSAGE);
                            		waitForClientBtn.setEnabled(true);
                            		typeInTextArea.setEditable(false);
                            	}
                            }
                        }).start();
                    }
                }
            );
		
		typeInTextArea.addKeyListener(
				new KeyListener() {
					public void keyPressed(KeyEvent e) {}
			        public void keyTyped(KeyEvent e) {}
			        public void keyReleased(KeyEvent e) {
			        	if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			        		String message = nickNameTextField.getText() + " > " + typeInTextArea.getText();
			        		messageTextArea.append(message);
			        		typeInTextArea.setText("");
			        		messageTextArea.setCaretPosition(messageTextArea.getText().length());
			        		chatServer.sendMessageToClient(message.replace('\n', ' '));
			        	}
			        }
				}
			);
	}
	
	public static void main(String[] args) {
		new SimpleChatServerUI();
	}
}
